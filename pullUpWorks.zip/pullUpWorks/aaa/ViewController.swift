
    

   import UIKit
    import CoreData
    
    
    class ViewController: UIViewController,UITextFieldDelegate {

        
        @IBOutlet var labelName : UILabel!
        @IBOutlet var enterT : UITextField!
        @IBOutlet var pic : UIImageView!
        lazy var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        
        var dx = [UIImage]()
        var names = [String]()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            

            enterT.delegate = self
            
            pic.backgroundColor = .cyan
            
            
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let managedContext = appDelegate.persistentContainer.viewContext
            let entity = NSEntityDescription.entity(forEntityName: "Users", in: managedContext)!
            let item = NSManagedObject(entity: entity, insertInto: managedContext)
                 let item2 = NSManagedObject(entity: entity, insertInto: managedContext)
            let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
            
            let vex = UIImage(named: "on.jpg")?.pngData()
            if let data = vex{
                item.setValue(data, forKey: "image")
                
            }
            
            
            
            
            let vex2 = UIImage(named: "house.jpg")?.pngData()
            if let data2 = vex2{
                item2.setValue(data2, forKey: "image")
            }
            
            
                 
                 
                 do {
                     let result = try? managedContext.fetch(fetch) as? [Users]
                     print("Queen",result?.count)
                     try? managedContext.save()
                     
                     
                     
                 }
                 catch {
                     print("Could not save")
                 }
                 
                 
        }

        
        func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            
            guard let text = (textField.text as? NSString)?.replacingCharacters(in: range, with: string), let index = Int(text) else { //here....
                // display an alert about invalid text
                return true
            }
            save(at: index )
            return true
        }
        
        func save(at index : Int) {
            let fetchRequest = NSFetchRequest<Users>(entityName: "Users")
            fetchRequest.predicate = NSPredicate(format: "idx == %d", Int32(index))
            do {
                if let user = try context.fetch(fetchRequest).first {
                    pic.image = user.image
                }
            } catch {
                print("Could not fetch \(error) ")
            }
            return
        }
        
        @IBAction func add(){
         
            
            fetch()
        }
        
        func fetch()
        {
            

            
            for i in 0..<dx.count {
                let newUser = Users(context: context)
                newUser.username = names[i]
                newUser.idx = Int32(i + 1)
                
                
            }
            print("Storing Data..")
            do {
                try context.save()
            } catch {
                print("Storing data Failed", error)
            }
            return
        }
        
        
    }
    
    
    
    
